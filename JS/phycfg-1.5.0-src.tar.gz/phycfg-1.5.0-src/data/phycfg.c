/*
 ****************************************************************
 **                                                            **
 **    (C)Copyright 2006-2009, American Megatrends Inc.        **
 **                                                            **
 **            All Rights Reserved.                            **
 **                                                            **
 **        5555 Oakbrook Pkwy Suite 200, Norcross,             **
 **                                                            **
 **        Georgia - 30093, USA. Phone-(770)-246-8600.         **
 **                                                            **
 ****************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include "libphyconf.h"
#include "nwcfg.h"

int
main(int argc, char **argv)
{
	int nInterfaces = 0;
	int index = 0;
	PHYConfigFile_T *configs = NULL;
	getTotalEthInterfaces(&nInterfaces);

	if(nInterfaces <= 0)
	{
		createDefaultPHYConfFile();
		getTotalEthInterfaces(&nInterfaces);

		if(nInterfaces <= 0)
		{
			printf("[PHYCFG] Configuration not found.\n");
			return 1;
		}
	}

	configs = (PHYConfigFile_T *)calloc(nInterfaces, sizeof(PHYConfigFile_T));
	if(getAllPHYConfigs(configs, nInterfaces) != 0)
	{
		printf("Get PHY configs failed. Creating a new default configuration file.....\n");
		createDefaultPHYConfFile();

		if(getAllPHYConfigs(configs, nInterfaces) != 0)
		{
			printf("[PHYCFG] Could not get configuration.\n");
			if(configs != NULL)
				free(configs);
			return 1;
		}
	}

	for(; index < nInterfaces; index++)
	{
		if(configs[index].autoNegotiationEnable == 1)
	  	{
#if 0	// No need to set the network link as AutoNegotiation explicitly, as the interface is already set to Auto-Negotiate, by default.
			/* Send 0xFF for both Speed and Duplex in case of Auto-Negotiation to differentiate with Force link mode */
			if(nwSetEthInformation(0xFF, 0xFF, configs[index].interfaceName) != 0)
			{
				printf("[PHYCFG] Error setting network link modes for interface: %s...\n", configs[index].interfaceName);
			}
#endif
		}
	   	else
		{
	    		if((configs[index].speed == 10 || configs[index].speed == 100 || configs[index].speed == 1000) && (configs[index].duplex == 0 || configs[index].duplex == 1))
	    		{
				if(nwSetEthInformation(configs[index].speed, configs[index].duplex, configs[index].interfaceName) !=0)
				{
					printf("[PHYCFG] Error setting network link modes for interface: %s...\n", configs[index].interfaceName);
				}
		   	}
		    	else
		    		printf("[PHYCFG] Invalid network link mode configuration for interface: %s...\n", configs[index].interfaceName);
	    	}
	}

	if(configs != NULL)
		free(configs);

	return 0;
}
