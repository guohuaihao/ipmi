/****************************************************************
 **                                                            										  **
 **    (C)Copyright 2006-2009, American Megatrends Inc.     **
 **                                                            										  **
 **            All Rights Reserved.                            						  **
 **                                                            										  **
 **        5555 Oakbrook Pkwy Suite 200, Norcross,             	  **
 **                                                            										  **
 **        Georgia - 30093, USA. Phone-(770)-246-8600.           **
 **                                                            										  **
 ****************************************************************/

#ifndef HTTPCONNECT_HANDLER_H
#define HTTPCONNECT_HANDLER_H

/*      define constant strings */

#define STR_CMD_BOUNDARY            "JVIEWER"
#define STR_CMD_BOUNDARY1            "VMCLI"
#define CMD_NAME                "name"
#define STR_BOUNDARY_END        "--"
#define STR_ENDOOFDATA          "\r\n\r\n"

#define C_EQUALSIGN             '='
#define C_BLANKSPACE            ' '
#define C_DBLQUOTE              '"'
#define C_HIPHEN                '-'
#define C_BOUNDARY_START_CHAR   'b'

/*      define error values     */
#define SUCCESS                 (0)
#define ERR_BOUNDARY_NOT_FOUND  (01)

/*  HTTPConnect state  */
#define HTTP_CONNECT_STATE_UNDEF   (-1)    /* Added to identify the socket close event during Http Connect */


#define CONN_START               (0)
#define CMD_START              (1)
#define INPROCESSING_CMDNAME   (2)
#define PROCESS_END        (3)
#define DISCONNECT_CMD        (4)
#define MAX_CMDNAME_SIZE 256

/*Service type*/
#define	VIDEO 	0
#define	CDMEDIA	1
#define FDMEDIA 2
#define HDMEDIA 3
#define DISCONNECT 4

/*  Maximum command size permitted */
#define MAX_CMD_SIZE_PERMITTED 1024

typedef char g3_char;

typedef struct HTTPConnectElement_tag
{
	short		state;      /* HttpConnect request for  */
	int 		sid;         /*  descriptor of the socket  */
	g3_char delimiter[MAX_CMDNAME_SIZE];

	/*      delimiter string        */
	int     cli_stopped;  /*  clear session  */
	int     ser_stopped;   /*  clear session  */
	int     expectedFileSize;    /*  expected file size mentioned by the web page    */
	g3_char  *dataString; /*      pointer to data string  */
	int     strSize;    /*  no of bytes of strStart */
	int 	ssl;
	unsigned char timeout;
} HTTPConnectElement;

#define CONNECT_TO_SERVICE		"connecttoserver"

extern int ProcessHttpConnectData();
extern int GetCmdStart(HTTPConnectElement *httpconnelement);
extern int InProcessingCmd(char *wp);
extern int ServiceCmd(char *wp,int servicetype);

#define ADVISER_SOCKET_PATH	"/var/adviser"
#define CD_SOCKET_PATH		"/var/CDServer"
#define FD_SOCKET_PATH		"/var/FDServer"
#define HD_SOCKET_PATH		"/var/HDServer"

#endif /*HTTPCONNECT_HANDLER_H*/

