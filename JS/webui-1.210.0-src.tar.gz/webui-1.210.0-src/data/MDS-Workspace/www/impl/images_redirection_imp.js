//;*****************************************************************;
//;*****************************************************************;
//;**                                                             **;
//;**     (C) COPYRIGHT American Megatrends Inc. 2011-2014        **;
//;**                     ALL RIGHTS RESERVED                     **;
//;**                                                             **;
//;**  This computer software, including display screens and      **;
//;**  all related materials, are confidential and the            **;
//;**  exclusive property of American Megatrends, Inc.  They      **;
//;**  are available for limited use, but only pursuant to        **;
//;**  a written license agreement distributed with this          **;
//;**  computer software.  This computer software, including      **;
//;**  display screens and all related materials, shall not be    **;
//;**  copied, reproduced, published or distributed, in whole     **;
//;**  or in part, in any medium, by any means, for any           **;
//;**  purpose without the express written consent of American    **;
//;**  Megatrends, Inc.                                           **;
//;**                                                             **;
//;**                                                             **;
//;**                American Megatrends, Inc.                    **;
//;**           5555 Oakbook Parkway, Building 200                **;
//;**     Norcross,  Georgia - 30071, USA. Phone-(770)-246-8600.  **;
//;**                                                             **;
//;*****************************************************************;
//;*****************************************************************;

// File Name  : configure_lmedia_imp.js
// Brief      : This implementation is to display the image files in list grid. 
// It contains implementation to add, replace and delete the image files.
// Author Name: Arockia Selva Rani. A

var LMEDIA_DATA;	//Holds RPC response data of local media images
var LMEDIA_ENABLE;	//Holds RPC response data of local media enable
var RMEDIA_IMAGE;	//Holds RPC response data of remote media images
var RMEDIA_ENABLE;	//Holds RPC response data of remote media enable
var RMEDIA_CFG;		//Holds RPC response data of remote media configuration

var LMEDIA_SUPPORT = false;
var RMEDIA_SUPPORT = false;

var tblJSON;		//Object to hold image information in JSON structure
var tblImage;		//List grid object to hold image information

var varMediaType;	//Integer to hold media type (local or remote media)
var varImageOper;	//Integer to hold Image operation (add, modify or delete)
var varImageType;	//Integer to hold Image type (Floppy, CD or Harddisk)
var varImageName;	//String to hold Image file name
var varAdvMediaFrm = false;	//Boolean to check for advanced settings form
var varFilePath = "";	//String to hold Image file path
var varImageNameList = [];	//List to hold existing Images list
var varImageTypeStr = [];	//List to hold the Image type

/*
 * The following are the constants used in this implementation.
 * The below listed is for media types available.
 */
var CONST_LMEDIA = 1;	//Constant for Local Media
var CONST_RMEDIA = 2;	//Constant for Remote Media
var CONST_MEDIA = 3;	//Constant for Media

var RMEDIA_SHRTYPE_NFS = 0;		//Constant for NFS share type
var RMEDIA_SHRTYPE_CIFS = 1;	//Constant for Samba (CIFS) share type

var IMAGE_TYPE_STR_FD = "Floppy";	//Constant for Floppy Image type
var IMAGE_TYPE_STR_CD = "CD/DVD";	//Constant for CD/DVD Image type
var IMAGE_TYPE_STR_HD = "Harddisk";	//Constant for Harddisk Image type

var LMEDIA_FILE_PATH = "/usr/local/tmplmedia/";	//Constant lmedia upload path

/*
 * This function will be called when its corresponding page gets loaded.
 * It will expose all the user controls and checks for user privilege.
 * Finally it will invoke the begin method. 
 */
function doInit()
{
	exposeElms(["_lblMediaDesc",
		"_tblTab",
		"_tabLMedia",
		"_tabRMedia",
		"_divMediaTab",
		"_btnAdvSettings",
		"_parImageDesc",
		"_lblHeader",
		"_lgdImage",
		"_btnStart",
		"_btnAdd",
		"_btnReplace",
		"_btnDelete"]);

	if(top.user.isAdmin()) {
		btnAdd.onclick = function() {
			doProcessImage(top.CONSTANTS.ADD);
		}
		btnReplace.onclick = function() {
			doProcessImage(top.CONSTANTS.MODIFY);
		}
		btnDelete.onclick = function() {
			doProcessImage(top.CONSTANTS.DELETE);
		}
	} else {
		disableActions();
	}

	btnAdvSettings.onclick = doMediaCfg;
	_begin();
}

/*
 * It will invoke the RPC method to get the data for the page.
 * Also initiate the local media tab as default tab.
 */
function _begin()
{
	LMEDIA_SUPPORT = checkProjectCfg("LMEDIA");
	RMEDIA_SUPPORT = checkProjectCfg("RMEDIA");
	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		tblTab.className = "visibleRow";
		tabLMedia.onclick = doLocalMedia;
		tabRMedia.onclick = doRemoteMedia;
		divMediaTab.className = "classicTabContent";

		var tabLastVisit = tabParser(top.mainFrame.pageFrame.location.hash);
		if (tabLastVisit != null) {
			$(tabLastVisit).onclick();
		} else {
			doRemoteMedia();
			doLocalMedia();
		}
	} else if (LMEDIA_SUPPORT) {
		doLocalMedia();
	} else if (RMEDIA_SUPPORT) {
		doRemoteMedia();
	}

	getMediaCfg();
}

/*
 * This will toggle the flag to true for advanced settings form.
 * Also invoke the RPC method to get the remote media configuration.
 */
function doMediaCfg()
{
	varAdvMediaFrm = true;
	if (RMEDIA_SUPPORT || LMEDIA_SUPPORT) {
		frmAdvMediaCfg();
	}
}

/*
 * It will invoke the RPC method to get the local media and remote media enable 
 * configuration. Once it get data from RPC, response function will be called 
 * automatically. 
 */
function getMediaCfg()
{
	varAdvMediaFrm = false;
	disableButtons();
	btnAdvSettings.disabled = false;
	xmit.get({url:"/rpc/getremotesession.asp", onrcv:getMediaCfgRes, 
		status:""});
}

/*
 * This is the response function for getMediaCfg RPC. 
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If success, move the response data to the global variable and load the output
 * data value in UI. 
 * @param arg object, RPC response data from xmit library
 */
function getMediaCfgRes(arg)
{
	var errstr;		//Error string
	if(arg.HAPI_STATUS != 0) {
		errstr = eLang.getString("common", "STR_MEDIA_CFG_GETVAL");
		errstr += (eLang.getString("common", "STR_IPMI_ERROR") + 
			GET_ERROR_CODE(arg.HAPI_STATUS));
		alert(errstr);
	} else {
		if (LMEDIA_SUPPORT) {
			LMEDIA_ENABLE = WEBVAR_JSONVAR_GETREMOTESESSIONCFG;
			LMEDIA_ENABLE = LMEDIA_ENABLE.WEBVAR_STRUCTNAME_GETREMOTESESSIONCFG;
			LMEDIA_ENABLE = LMEDIA_ENABLE[0].LMEDIAENABLE;
		}

		if (RMEDIA_SUPPORT) {
			RMEDIA_ENABLE = WEBVAR_JSONVAR_GETREMOTESESSIONCFG;
			RMEDIA_ENABLE = RMEDIA_ENABLE.WEBVAR_STRUCTNAME_GETREMOTESESSIONCFG;
			RMEDIA_ENABLE = RMEDIA_ENABLE[0].RMEDIAENABLE;
		}

		if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
			if (!LMEDIA_ENABLE && !RMEDIA_ENABLE) {
				addMediaDesc("MEDIA", CONST_MEDIA);
			} else if (!LMEDIA_ENABLE) {
				addMediaDesc("MEDIA", CONST_LMEDIA);
			} else if (!RMEDIA_ENABLE) {
				addMediaDesc("MEDIA", CONST_RMEDIA);
			}
		} else if (LMEDIA_SUPPORT) {
			addMediaDesc("LMEDIA", LMEDIA_ENABLE ? 0 : 1);
		} else if (RMEDIA_SUPPORT) {
			addMediaDesc("RMEDIA", RMEDIA_ENABLE ? 0 : 1);
		}
	}
}

function addMediaDesc(strMedia, disable)
{
	lblMediaDesc.innerHTML = eLang.getString("common",
		"STR_" + strMedia + "_DESC");
	if (disable) {
		lblMediaDesc.innerHTML += eLang.getString("common",
			"STR_" + strMedia + "_DISABLE_" + disable);
	}
	lblMediaDesc.innerHTML += eLang.getString("common",
		"STR_" + strMedia + "_ADV_DESC");
}

/*
 * This will design the UI controls for Advanced Media configuration form.
 */
function frmAdvMediaCfg()
{
	var frm = new form("advancedMediaFrm", "POST", "javascript://", "general");

	if (LMEDIA_SUPPORT) {
		settings = frm.addCheckBox(eLang.getString("common",
			"STR_LMEDIA_ENABLE"), "chkLMediaEnable",
			{"chkLMediaEnable":"Enable"}, false, ["chkLMediaEnable"]);
		chkLMediaEnable = settings.chkLMediaEnable;
	}

	if (RMEDIA_SUPPORT) {
		settings = frm.addCheckBox(eLang.getString("common",
			"STR_RMEDIA_ENABLE"), "chkRMediaEnable",
			{"chkRMediaEnable":"Enable"}, false, ["chkRMediaEnable"]);
		chkRMediaEnable = settings.chkRMediaEnable;

		txtServerIP = frm.addTextField(eLang.getString("common",
			"STR_SERVER_ADDRESS"), "_txtServerIP", RMEDIA_CFG.IP_ADDR,
			{"maxLength":39}, "bigclassicTxtBox");

		txtSrcPath = frm.addTextField(eLang.getString("common",
			"STR_SOURCE_PATH"), "_txtSrcPath", RMEDIA_CFG.SRC_PATH,
			{"maxLength":256}, "bigclassicTxtBox");

		var valShareType = {0:"NFS", 1:"Samba(CIFS)"};
		lstShrType = frm.addSelectBox(eLang.getString("common",
			"STR_RMEDIA_SHR_TYPE"), "_lstShrType", valShareType,
			RMEDIA_CFG.SHR_TYPE, "", "", "classicTxtBox");

		txtUname = frm.addTextField(eLang.getString("common", "STR_USERNAME"),
			"_txtUname", RMEDIA_CFG.UNAME, {"maxLength":256}, "classicTxtBox");

		txtPword = frm.addPasswordField(eLang.getString("common",
			"STR_PASSWORD"), "_txtPword", "", {"maxLength":32}, "classicTxtBox");

		txtDomainName = frm.addTextField(eLang.getString("common",
			"STR_DOMAINNAME"), "_txtDomainName", RMEDIA_CFG.DOMAIN_NAME,
			{"maxLength":256}, "bigclassicTxtBox");
	}

	var btnAry = [];
	btnAry.push(createButton("btnSave", eLang.getString("common",
		"STR_SAVE"), validateMediaCfg));
	btnAry.push(createButton("btnCancel", eLang.getString("common",
		"STR_CANCEL"), closeForm));

	wnd = MessageBox(eLang.getString("common", "STR_MEDIA_ADV_TITLE"),
		frm.display(), btnAry);
	wnd.onclose = function (){
		getMediaCfg();
		if (varMediaType == CONST_LMEDIA) {
			getLMediaArea();
		} else if (varMediaType == CONST_RMEDIA) {
			getRMediaCfg();
		}
	};

	if (LMEDIA_SUPPORT) {
		chkLMediaEnable.onclick = enableLMedia;
		chkLMediaEnable.checked = LMEDIA_ENABLE ? true : false;
		enableLMedia();
	}

	if (RMEDIA_SUPPORT) {
		chkRMediaEnable.onclick = enableRMedia;
		lstShrType.onchange = doShareType;
		chkRMediaEnable.checked = RMEDIA_ENABLE ? true : false;
		enableRMedia();
	}

	if (LMEDIA_SUPPORT && !RMEDIA_ENABLE) {
		chkLMediaEnable.focus();
	} else {
		chkRMediaEnable.focus();
	}	
	if(!top.user.isAdmin()) {
		disableActions({id:["_btnAdvSettings", "_btnCancel"]});
	}
}

/*
 * This will enable or disable the local media UI controls based on local 
 * media enable support check box value. 
 * NOTE: Both local and remote media should not be enabled at a time.
 */
function enableLMedia()
{
	var opt;
	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		opt = chkLMediaEnable.checked;
		chkRMediaEnable.disabled = opt;
		if (opt) {
			chkRMediaEnable.checked = !opt;
		}
		enableRMedia();
	}
}

/*
 * This will enable or disable the remote media UI controls based on local 
 * media enable support check box value.
 * NOTE: Both local and remote media should not be enabled at a time.
 */
function enableRMedia()
{
	var opt;
	opt = !chkRMediaEnable.checked;
	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		if (!opt) {
			chkLMediaEnable.checked = opt;
		}
		chkLMediaEnable.disabled = !opt;
	}
	txtServerIP.disabled = opt;
	txtSrcPath.disabled = opt;
	lstShrType.disabled = opt;
	doShareType();
}

/*
 * This will enable or disable the user authentication controls based on 
 * share type. Samba(CIFS) requires user authentication details.
 */
function doShareType()
{
	var opt;
	opt = ((RMEDIA_SHRTYPE_NFS == lstShrType.value) ||
		(lstShrType.disabled));
	txtUname.disabled = opt;
	txtPword.disabled = opt;
	txtDomainName.disabled = opt;
}

/*
 * It will validate the advanced media configuration data before saving it.
 */
function validateMediaCfg()
{
	if (RMEDIA_SUPPORT) {
		if (chkRMediaEnable.checked) {
			if ((!eVal.ip(txtServerIP.value)) && 
				(!eVal.ipv6(txtServerIP.value, true, false))) {
				alert(eLang.getString("common", "STR_INVALID_SERVERADDR") +
					eLang.getString("common", "STR_HELP_INFO"));
				txtServerIP.focus();
				return;
			}

			if (eVal.isblank(txtSrcPath.value)) {
				alert(eLang.getString("common", "STR_INVALID_SRC_PATH") +
					eLang.getString("common", "STR_HELP_INFO"));
				txtSrcPath.focus();
				return;
			}

			if (RMEDIA_SHRTYPE_CIFS == lstShrType.value) {
				if (!eVal.username(txtUname.value, "", 1, 256)) {
					alert(eLang.getString("common", "STR_INVALID_USERNAME") +
						eLang.getString("common", "STR_HELP_INFO"));
					txtUname.focus();
					return;
				}

				if (!eVal.password(txtPword.value, 1, 32)) {
					alert(eLang.getString("common", "STR_INVALID_PASSWORD") +
						eLang.getString("common", "STR_HELP_INFO"));
					txtPword.focus();
					return;
				}

				if (!eVal.domainname(txtDomainName.value, true)) {
					alert (eLang.getString("common", "STR_INVALID_DOMAIN") +
						eLang.getString("common", "STR_HELP_INFO"));
					txtDomainName.focus();
					return;
				}
			}
		}
	}
	setMediaCfg();
}

/*
 * It will invoke the RPC method to set the advanced media configuration.
 * Once it get response from RPC, on receive method will be called automatically.
 */
function setMediaCfg()
{
	var req;			//xmit object to send RPC request with parameters

	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		if ((LMEDIA_ENABLE == chkLMediaEnable.checked) &&
			(RMEDIA_ENABLE == chkRMediaEnable.checked) &&
			(RMEDIA_CFG.IP_ADDR == txtServerIP.value) &&
			(RMEDIA_CFG.SRC_PATH == txtSrcPath.value) &&
			(RMEDIA_CFG.SHR_TYPE == lstShrType.value) &&
			(RMEDIA_CFG.UNAME == txtUname.value) &&
			(RMEDIA_CFG.PWORD == txtPword.value) &&
			(RMEDIA_CFG.DOMAIN_NAME == txtDomainName.value)) {
			return false;
		}
	} else if (LMEDIA_SUPPORT) {
		if (LMEDIA_ENABLE == chkLMediaEnable.checked) {
			return false;
		}
	} else if (RMEDIA_SUPPORT) {
		if ((RMEDIA_ENABLE == chkRMediaEnable.checked) &&
			(RMEDIA_CFG.IP_ADDR == txtServerIP.value) &&
			(RMEDIA_CFG.SRC_PATH == txtSrcPath.value) &&
			(RMEDIA_CFG.SHR_TYPE == lstShrType.value) &&
			(RMEDIA_CFG.UNAME == txtUname.value) &&
			(RMEDIA_CFG.PWORD == txtPword.value) &&
			(RMEDIA_CFG.DOMAIN_NAME == txtDomainName.value)) {
			return false;
		}
	}

	if (confirm(eLang.getString("common", "STR_MEDIA_CFG_CONFIRM"))) {
		req = new xmit.getset({url:"/rpc/setmediacfg.asp", 
			onrcv:setMediaCfgRes, status:""});
		if (LMEDIA_SUPPORT) {
			req.add("LMEDIAENABLE", (chkLMediaEnable.checked) ? 1 : 0);
		}
		if (RMEDIA_SUPPORT) {
			req.add("RMEDIAENABLE", (chkRMediaEnable.checked) ? 1 : 0);
			req.add("IP_ADDR", txtServerIP.value);
			req.add("SRC_PATH", txtSrcPath.value);
			req.add("SHR_TYPE", lstShrType.value);
			req.add("UNAME", txtUname.value);
			req.add("PWORD", txtPword.value);
			req.add("DOMAIN_NAME", txtDomainName.value);
		}
		req.send();
		delete req;
	}
}

/*
 * This is the response function for setMediaCfg RPC. 
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If zero, then set advanced media configuration is success, intimate proper 
 * message to end user.
 * @param arg object, RPC response data from xmit library
 */
function setMediaCfgRes(arg)
{
	if(arg.HAPI_STATUS != 0) {
		errstr = eLang.getString("common", "STR_MEDIA_CFG_SETVAL");
		errstr += (eLang.getString("common", "STR_IPMI_ERROR") + 
			GET_ERROR_CODE(arg.HAPI_STATUS));
		alert(errstr);
	} else {
		alert (eLang.getString("common", "STR_MEDIA_CFG_SUCCESS"));
		closeForm();
	}
}

/*
 * This function is used to load the list grid and its header information.
 * Also initializes the list grid select and double click event handler.
 */
function loadCustomPageElements()
{
	var image_colhead3;
	lgdImage.innerHTML = "";
	tblImage = listgrid({
		w : "100%",
		doAllowNoSelect : false
	});

	lgdImage.appendChild(tblImage.table);
	if (varMediaType == CONST_LMEDIA) {
		image_colhead3 = eLang.getString("common", "STR_LMEDIA_IMGINFO");
	} else if (varMediaType == CONST_RMEDIA) {
		image_colhead3 = eLang.getString("common", "STR_RMEDIA_STATUS");
	}

	tblJSON = {cols:[
		{text:eLang.getString("common", "STR_HASH"), fieldType:2, w:"10%",
			textAlign:"center"},
		{text:eLang.getString("common", "STR_MEDIA_IMGTYPE"), w:"30%",
			textAlign:"center"},
		{text:eLang.getString("common", "STR_MEDIA_IMGNAME"), w:"30%",
			textAlign:"center"},
		{text:image_colhead3, w:"30%", textAlign:"center"}
		]};

	tblImage.loadFromJson(tblJSON);

	/*
	 * This event handler will be invoked when the list grid row is selected.
	 */
	tblImage.ontableselect = function()
	{
		var imgname;		//Selected image name
		var media_enable;	//Local or remote media enable
		disableButtons();
		if (varMediaType == CONST_LMEDIA) {
			media_enable = LMEDIA_ENABLE;
		} else if (varMediaType == CONST_RMEDIA) {
			media_enable = RMEDIA_ENABLE;
		}

		if(top.user.isAdmin() && media_enable) {
			if (this.selected.length) {
				imgname = tblImage.getRow(tblImage.selected[0]).cells[2].innerHTML;
				imgname.replace("&nbsp;","").replace(" ","");
				if (imgname == "~") {
					btnAdd.disabled = false;
				}

				if (varMediaType == CONST_LMEDIA) {
					if (imgname != "~") {
						btnReplace.disabled = false;
						btnDelete.disabled = false;
					}
				} else if (varMediaType == CONST_RMEDIA) {
					redir_status = tblImage.getRow(tblImage.selected[0]);
					redir_status = redir_status.cells[3].innerHTML;
					if (redir_status.indexOf(eLang.getString("common", 
						"STR_RMEDIA_STATUS_START")) != -1) {
						btnStart.disabled = false;
						btnStart.value = eLang.getString("common",
							"STR_RMEDIA_STOP_REDIR");
						btnStart.onclick = function (){ doStartRedirection(0)}
					} else if (redir_status.indexOf(eLang.getString("common", 
						"STR_RMEDIA_STATUS_STOP")) != -1) {
						btnStart.disabled = false;
						btnStart.value = eLang.getString("common",
							"STR_RMEDIA_START_REDIR");
						btnStart.onclick = function (){ doStartRedirection(1);}
						if (imgname != "~") {
							btnReplace.disabled = false;
							btnDelete.disabled = false;
						}
					} else /*if (redir_status.indexOf(eLang.getString("common", 
						"STR_RMEDIA_STATUS_PROGRESS")) != -1) */ {
						btnStart.disabled = true;
						btnStart.value = eLang.getString("common",
							"STR_RMEDIA_START_REDIR");
						btnStart.onclick = function (){};
					}
				}
			}
		}
	}

	/*
	 * This event handler will be invoked when double click in list grid row.
	 */
	tblImage.ondblclick = function()
	{
		var imgname;		//Selected image name
		var media_enable;	//Local or remote media enable
		if (varMediaType == CONST_LMEDIA) {
			media_enable = LMEDIA_ENABLE;
		} else if (varMediaType == CONST_RMEDIA) {
			media_enable = RMEDIA_ENABLE;
		}

		if(top.user.isAdmin() && media_enable) {
			imgname = tblImage.getRow(tblImage.selected[0]).cells[2].innerHTML;
			imgname.replace("&nbsp;","").replace(" ","");
			if (imgname == "~") {
				doProcessImage(top.CONSTANTS.ADD);	//Adding image
			} else {
				if (varMediaType == CONST_LMEDIA) {
					doProcessImage(top.CONSTANTS.MODIFY);	//Replacing image
				} else if (varMediaType == CONST_RMEDIA) {
					redir_status = tblImage.getRow(tblImage.selected[0]);
					redir_status = redir_status.cells[3].innerHTML;
					if (redir_status.indexOf(eLang.getString("common", 
						"STR_RMEDIA_STATUS_STOP")) != -1) {
						doProcessImage(top.CONSTANTS.MODIFY);	//Replacing image
					}
				}
			}
		}
	}
}

/*
 * This will get index from the selected row of list grid, based on the data
 * in selected row, it will invoke either add, replace or delete image method.
 * @param imageoper integer, Image operation. 1-Add, 2-Replace, 3-Delete.
 */
function doProcessImage(imageoper)
{
	var index;			//Index of the list grid
	var image_exists;	//boolean to hold image exists or not
	var image_name;		//string to hold image name
	var fnMediaAddImage;		//function to add media image
	var fnMediaReplaceImage;	//function to replace media image
	var fnMediaDeleteImage;		//function to delete media image

	if ((tblImage.selected.length != 1) || 
		(tblImage.selected[0].cells[0] == undefined) || 
		(tblImage.selected[0].cells[0] == null)) {
		alert(eLang.getString("common", "STR_MEDIA_IMG_ERR1"));
		disableButtons();
	} else {
		index = tblImage.getRow(tblImage.selected[0]).cells[0].innerHTML;
		index = parseInt(index);
		image_name = tblImage.getRow(tblImage.selected[0]).cells[2].innerHTML;
		image_exists = (image_name != "~") ? true : false;
		varImageOper = imageoper;	//Storing operation value for future use
		if (varMediaType == CONST_LMEDIA) {
			fnMediaAddImage = frmLMediaAddImage;
			fnMediaReplaceImage = frmLMediaReplaceImage;
		} else if (varMediaType == CONST_RMEDIA) {
			fnMediaAddImage = frmRMediaAddImage;
			fnMediaReplaceImage = frmRMediaReplaceImage;
		}
		switch(imageoper) {
		case top.CONSTANTS.ADD:
			if (image_exists) {
				if (confirm(eLang.getString("common", "STR_MEDIA_CONFIRM1"))) {
					fnMediaReplaceImage(index);
				}
			} else {
				fnMediaAddImage(index);
			}
			break;
		case top.CONSTANTS.MODIFY:
			if (!image_exists) {
				if (confirm(eLang.getString("common", "STR_MEDIA_CONFIRM2"))) {
					fnMediaAddImage(index);
				}
			} else {
				fnMediaReplaceImage(index);
			}
			break;
		case top.CONSTANTS.DELETE:
			if (!image_exists) {
				alert (eLang.getString("common", "STR_MEDIA_IMG_ERR2"));
			} else {
				if (confirm(eLang.getString("common", "STR_CONFIRM_DELETE"))) {
					varImageType = tblImage.getRow(tblImage.selected[0]);
					varImageType = varImageType.cells[1].innerHTML;
					varImageName = "";
					setMediaImage();
				}
			}
			break;
		}
	}
}

/*
 * It will compare the filename with already existing filenames.
 * @param fnametocmp string, filename to compare.
 * @param imgtypetocmp string, media type to compare.
 * @return boolean, true-filename matches, false-no match.
 */
function compareFilename(fnametocmp, imgtypetocmp)
{
	var fname = "";	//filename
	var i;		//loop counter
	var splitfnametocmp = "";

	splitfnametocmp = fnametocmp.split("\/");
	if (splitfnametocmp.length) {
		fnametocmp = splitfnametocmp[splitfnametocmp.length - 1];
	} else {
		fnametocmp = splitfnametocmp[0];
	}

	for (i = 0; i < varImageNameList.length; i++) {
		fname = varImageNameList[i].split("\/");
		if (fname.length) {
			fname = fname[fname.length-1];
		} else {
			fname = fname[0];
		}

		if (imgtypetocmp != varImageTypeStr[i]) {
			if (fname == fnametocmp) {
				return true;
			}
		}
	}
	return false;
}

/*
 * It will validate the data of all media image user controls before saving it.
 * @param imageType number, specifies the image type floppy, CD/DVD or harddisk.
 * @param imageName string, specifies the image file name.
 * @param fnToSave function, specifies the function to be invoked for set
 * operation.
 */
function validateMediaImage(imageType, imageName, fnToSave)
{
	var filename;			//File name

	if (eVal.isblank(imageName)) {
		alert (eLang.getString("common", "STR_MEDIA_INVALID_FILE1"));
		return;
	}
	if ((imageType.indexOf(IMAGE_TYPE_STR_FD) != -1) || 
		(imageType.indexOf(IMAGE_TYPE_STR_HD) != -1)) {
		//Image type is Floppy or Harddisk should have extension of .img
		if(!eVal.endsWith(imageName,".img")) {
			alert (eLang.getString("common", "STR_MEDIA_INVALID_FDIMG"));
			return;
		}
	}
	if (imageType.indexOf(IMAGE_TYPE_STR_CD) != -1) {
		//Image type is CD/DVD should have extension of .iso
		if(!eVal.endsWith(imageName,".iso")) {
			alert (eLang.getString("common", "STR_MEDIA_INVALID_CDIMG"));
			return;
		}
	}

	varImageType = imageType;
	varImageName = imageName;
	varFilePath = imageName;

	if (varMediaType == CONST_LMEDIA) {
		varFilePath = LMEDIA_FILE_PATH + imageName;
	}

	if (compareFilename(varFilePath, varImageType)){
		alert (eLang.getString("common", "STR_MEDIA_INVALID_FILE2"));
		return;
	}

	fnToSave();
}

/*
 * It will invoke the RPC method to set the media image configuration for
 * both local or remote image configuration.
 * Once it get response from RPC, on receive method will be called automatically.
 */
function setMediaImage()
{
	var req;			//xmit object to send RPC request with parameters
	req = new xmit.getset({url:"/rpc/setmediaimage.asp", 
		onrcv:setMediaImageRes, status:""});
	req.add("MEDIA_TYPE", varMediaType);
	req.add("IMAGE_OPER", varImageOper);
	req.add("IMAGE_TYPE", varImageType);
	req.add("IMAGE_NAME", varImageName);
	req.send();
	delete req;
}

/*
 * This is the response function for setMediaImage RPC. 
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If zero, then set media  image configuration is success, intimate proper 
 * message to end user.
 * @param arg object, RPC response data from xmit library
 */
function setMediaImageRes(arg)
{
	var errstr;		//Error string

	if (varImageOper == top.CONSTANTS.ADD) {
		$("_btnAddImage").disabled = false;
	} else if (varImageOper == top.CONSTANTS.MODIFY) {
		$("_btnReplaceImage").disabled = false;
	} else if (varImageOper == top.CONSTANTS.DELETE) {
		if (varMediaType == CONST_LMEDIA) {
			getLMediaArea();
		} else if (varMediaType == CONST_RMEDIA) {
			getRMediaCfg();
		}
	}

	if (varImageOper != top.CONSTANTS.DELETE) {
		$("_btnCancel").disabled = false;
		if (varMediaType == CONST_LMEDIA) {
			$("_fleImageBrowse").disabled = false;
		}
	}

	if(arg.HAPI_STATUS != 0) {
		switch(GET_ERROR_CODE(arg.HAPI_STATUS)) {
		case 0xE1:
			errstr = eLang.getString("common", "STR_MEDIA_INVALID_FILE2")
		break;
		default:
			if (varMediaType == CONST_LMEDIA) {
				errstr = eLang.getString("common", "STR_LMEDIA_IMG_SETVAL");
			} else if (varMediaType == CONST_RMEDIA) {
				errstr = eLang.getString("common", "STR_RMEDIA_IMG_SETVAL");
			}
			errstr += eLang.getString("common", "STR_IPMI_ERROR") + 
				GET_ERROR_CODE(arg.HAPI_STATUS);
		break;
		}
		alert(errstr);
	} else {
		alert (eLang.getString("common", "STR_MEDIA_IMG_SUCCESS" + 
			varImageOper));
		closeForm();
	}
}

/*
 * It will disable the buttons.
 */
function disableButtons()
{
	btnAdd.disabled = true;
	btnReplace.disabled = true;
	btnDelete.disabled = true;
}

/*
 * Used to close the form which is used to add or replace the image
 */
function closeForm()
{
	wnd.close();
}

/*
 * It will highlight the local media tab and do local media operations.
 */
function doLocalMedia()
{
	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		tabLMedia.style.fontWeight = "bold";
		tabRMedia.style.fontWeight = "normal";
		reloadHelp();
	}
	varMediaType = CONST_LMEDIA;
	btnStart.className = "hiddenRow";
	loadCustomPageElements();
	getLMediaArea();
}

/*
 * It will invoke the RPC method to get the local media image configuration.
 * Once it get data from RPC, response function will be called automatically.
 */
function getLMediaArea()
{
	disableButtons();
	xmit.get({url:"/rpc/getlmediaimage.asp", onrcv:getLMediaAreaRes, status:""});
}

/*
 * This is the response function for getLMediaArea RPC.
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If success, move the response data to the global variable and invoke the 
 * method to load the data value in UI. 
 * @param arg object, RPC response data from xmit library
 */
function getLMediaAreaRes(arg)
{
	var errstr;		//Error string
	if(arg.HAPI_STATUS != 0) {
		errstr = eLang.getString("common", "STR_LMEDIA_IMG_GETVAL");
		errstr += (eLang.getString("common","STR_IPMI_ERROR") + 
			GET_ERROR_CODE(arg.HAPI_STATUS));
		alert(errstr);
	} else {
		LMEDIA_DATA = WEBVAR_JSONVAR_GETLMEDIAIMAGE.WEBVAR_STRUCTNAME_GETLMEDIAIMAGE;
		loadLMediaImageTable();
		btnAdvSettings.disabled = false;
	}
}


/*
 * It will load response local media data from global variable to list grid 
 * control in UI.
 */
function loadLMediaImageTable()
{
	var imagename_todisplay;	//File name of image to display in List grid
	var imagetype_todisplay;	//Image type to display in List grid
	var imageinfo_todisplay;	//Image information to display in List grid
	var image_count = 0;		//Number of available image files
	var index;					//loop counter
	var i = 0;					//index value for Images list
	var rowJSON = [];			//Object of array of rows to load list grid

	tblImage.clear();
	varImageNameList = [];
	varImageTypeStr = [];
	for (index = 0; index < LMEDIA_DATA.length; index++) {
		// Use ~ char to indicate free slot so it will sort alphabetically
		imagetype_todisplay = LMEDIA_DATA[index].IMAGE_TYPE_STR;
		imagename_todisplay = "~";
		imageinfo_todisplay = "~";

		if ((LMEDIA_DATA[index].IMAGE_NAME != "") && 
			(LMEDIA_DATA[index].IMAGE_INFO != "") && 
			(LMEDIA_DATA[index].IMAGE_EXISTS != 0)) {
			imagename_todisplay = LMEDIA_DATA[index].IMAGE_NAME;
			varImageTypeStr[i] = imagetype_todisplay;
			varImageNameList[i] = imagename_todisplay;
			imageinfo_todisplay = LMEDIA_DATA[index].IMAGE_INFO;
			image_count++;
			i++;
		}
		try {
			rowJSON.push({cells:[
				{text:(index+1), value:(index+1)},
				{text:imagetype_todisplay, value:imagetype_todisplay},
				{text:imagename_todisplay, value:imagename_todisplay},
				{text:imageinfo_todisplay, value:imageinfo_todisplay}
			]});
		} catch(e) {
			alert(e);
		}
	}

	tblJSON.rows = rowJSON;
	tblImage.loadFromJson(tblJSON);
	lblHeader.innerHTML = "<strong class='st'>" + 
		eLang.getString("common", "STR_MEDIA_IMG_CNT") + "</strong>" + 
		image_count + eLang.getString("common", "STR_BLANK");
}

/*
 * It will design the form, which contains UI controls to add or replace image
 * for local media configuration, based on the argument value.
 * @param arg object, contains basic details of the selected slot in list 
 * grid and also details to load the form for add or replace image.
 */
function frmLMediaProcessImage(arg)
{
	var frm = new form(arg.frmName,"POST","javascript://","general");

	txtImageType = frm.addTextField(eLang.getString("common", 
		"STR_MEDIA_IMGTYPE"), "_txtImageType", 
		arg.imgType, {"readOnly":true}, "classicTxtBox");
	varImageType = arg.imgType;

	if (arg.imgName != undefined) {
		txtImageInfo = frm.addTextField(eLang.getString("common", 
			"STR_LMEDIA_IMGINFO"), "_txtImageInfo", 
			arg.imgName, {"readOnly":true}, "bigclassicTxtBox");
	}

	var divFileupload = document.createElement("div");
	divFileupload.innerHTML = "<form name='frmImageUpload' id='_frmImageUpload'" +
		" method='POST' enctype='multipart/form-data' action='file_upload.html'" +
		" target='hiddenFrame' style='margin-bottom:0'><input type='file'" +
		" id='_fleImageBrowse' size='35' /></form>";
	rowImageBrowse = frm.addRow(eLang.getString("common", "STR_LMEDIA_IMGFILE"),
		divFileupload);

	var btnAry = [];
	btnAry.push(createButton(arg.btnName, eLang.getString("common", 
		arg.btnValue), validateLMediaImage));
	btnAry.push(createButton("btnCancel", eLang.getString("common", 
		"STR_CANCEL"), closeForm));

	wnd = MessageBox(eLang.getString("common", arg.wndTitle),
		frm.display(), btnAry);
	//Ignores backspace functionality
	txtImageType.onkeydown = checkBackspace;
	if (arg.imgOper == top.CONSTANTS.MODIFY) {
		txtImageInfo.onkeydown = checkBackspace;
	}
	wnd.onclose = getLMediaArea;
}

/*
 * It will display a form, which contains UI controls to add a new image to
 * local media.
 * @param index number, index of the selected slot in list grid.
 */
function frmLMediaAddImage(index)
{
	frmLMediaProcessImage ({
		"frmName" : "addLMediaImageForm",
		"imgType" : LMEDIA_DATA[index-1].IMAGE_TYPE_STR,
		"btnValue" : "STR_ADD",
		"btnName" : "btnAddImage",
		"wndTitle" : "STR_MEDIA_ADD_IMAGE"
	});
}

/*
 * It will display a form, which contains UI controls to replace a image to
 * local media.
 * @param index number, index of the selected slot in list grid.
 */
function frmLMediaReplaceImage(index)
{
	frmLMediaProcessImage ({
		"frmName" : "replaceLMediaImageForm",
		"imgName" : LMEDIA_DATA[index-1].IMAGE_INFO,
		"imgType" : LMEDIA_DATA[index-1].IMAGE_TYPE_STR,
		"btnValue" : "STR_REPLACE",
		"btnName" : "btnReplaceImage",
		"wndTitle" : "STR_MEDIA_REPLACE_IMAGE"
	});
}

/*
 * It will get the local media image file name from the control and invoke 
 * validation method to validate it.
 */
function validateLMediaImage()
{
	var fleImageBrowse;		//File Image Browse control
	var filename;

	fleImageBrowse = $("_fleImageBrowse");
	filename = fleImageBrowse.value.split("\\");
	if (filename.length) {
		filename = filename[filename.length - 1];
	} else {
		filename = filename[0];
	}

	validateMediaImage(txtImageType.value, filename, uploadImage);
}

/*
 * It will upload the file to web server. Once upload was completed, it will
 * call the uploadComplete method automatically. 
 */
function uploadImage()
{
	var filepath_size;	//File path with file size
	var filesize;		//File size
	var fleImageBrowse;	//File Image Browse control

	if (confirm(eLang.getString("common", "STR_LMEDIA_CNFM_UPLOAD" 
		+ varImageOper))) {

		if (varImageOper == top.CONSTANTS.ADD) {
			$("_btnAddImage").disabled = true;
		} else if (varImageOper == top.CONSTANTS.MODIFY) {
			$("_btnReplaceImage").disabled = true;
		}

		fleImageBrowse = $("_fleImageBrowse");
		if (fnCookie.read("WebServer").indexOf("lighttpd") != -1) {
			fleImageBrowse.name = varFilePath;
		} else {
			//8GB maximum size (8*1024*1024*1024)   now 16MB
			filesize = 1024 * 1024 * 16 * 1;
			filepath_size = varFilePath + "?" + filesize;
			fleImageBrowse.name = filepath_size;
		}

		showWait(true, "Uploading");
		parent.web_alerts.stop();
		document.forms["frmImageUpload"].submit();

		$("_btnCancel").disabled = true;
		fleImageBrowse.disabled = true;
	}
}

/*
 * Once the upload completed, the control comes to this method.
 * This will invoke the set media image configuration.
 */
function uploadComplete()
{
	showWait(false);
	parent.web_alerts.monitor();
	setMediaImage();
}

/*
 * It will highlight the remote media tab and do remote media operations.
 */
function doRemoteMedia()
{
	if (LMEDIA_SUPPORT && RMEDIA_SUPPORT) {
		tabLMedia.style.fontWeight = "normal";
		tabRMedia.style.fontWeight = "bold";
		reloadHelp();
	}
	varMediaType = CONST_RMEDIA;
	btnStart.className = "visibleRow";
	btnStart.disabled = true;
	loadCustomPageElements();
	getRMediaCfg();
}

/*
 * It will invoke the RPC method to get the remote media image configuration.
 * Once it get data from RPC, response function will be called automatically.
 */
function getRMediaCfg()
{
	disableButtons();
	xmit.get({url:"/rpc/getrmediacfg.asp", onrcv:getRMediaCfgRes, status:""});
}

/*
 * This is the response function for getRMediaCfg RPC. 
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If success, move the response data to the global variable and invoke the 
 * method to load the data value in UI. 
 * @param arg object, RPC response data from xmit library
 */
function getRMediaCfgRes(arg)
{
	var errstr;		//Error string
	if(arg.HAPI_STATUS != 0) {
		errstr = eLang.getString("common", "STR_RMEDIA_IMG_GETVAL");
		errstr += (eLang.getString("common", "STR_IPMI_ERROR") + 
			GET_ERROR_CODE(arg.HAPI_STATUS));
		alert(errstr);
	} else {
		RMEDIA_CFG = WEBVAR_JSONVAR_GETRMEDIACFG.WEBVAR_STRUCTNAME_GETRMEDIACFG[0];
		RMEDIA_IMAGE = WEBVAR_JSONVAR_GETRMEDIACFG.WEBVAR_STRUCTNAME_GETRMEDIACFG;
		if (varAdvMediaFrm) {
			frmAdvMediaCfg();
		} else if (varMediaType == CONST_RMEDIA) {
			loadRMediaImageTable();
			btnAdvSettings.disabled = false;
		}
	}
}

/*
 * It will load response remote media data from global variable to list grid 
 * control in UI.
 */
function loadRMediaImageTable()
{
	var imagetype_todisplay;	//Image type to display in List grid
	var imagename_todisplay;	//File name of image to display in List grid
	var redirstatus_todisplay;	//Image information to display in List grid
	var image_count = 0;		//Number of available image files
	var index;					//loop counter
	var i = 0;					//index value for Images list
	var rowJSON = [];			//Object of array of rows to load list grid

	tblImage.clear();
	varImageNameList = [];
	varImageTypeStr = [];
	for (index = 0; index < RMEDIA_IMAGE.length; index++) {
		// Use ~ char to indicate free slot so it will sort alphabetically
		imagetype_todisplay = RMEDIA_IMAGE[index].IMG_TYPE;
		imagename_todisplay = "~";
		redirstatus_todisplay = "~";

		if (RMEDIA_IMAGE[index].IMG_NAME != "") {
			imagename_todisplay = RMEDIA_IMAGE[index].IMG_NAME;
			varImageTypeStr[i] = imagetype_todisplay;
			varImageNameList[i] = imagename_todisplay;
			if (RMEDIA_IMAGE[index].START_FLAG == 0) {
				redirstatus_todisplay = "<label class='classicLabel'>" +
					eLang.getString("common", "STR_RMEDIA_STATUS_STOP") +
					"</label>";
			} else {
				if (RMEDIA_IMAGE[index].STATUS_FLAG == 100) {
					redirstatus_todisplay = "<label class='classicLabel'>" +
						eLang.getString("common", "STR_RMEDIA_STATUS_PROGRESS") +
						"</label>";
				} else if ((RMEDIA_IMAGE[index].STATUS_FLAG == 0) ||
					(RMEDIA_IMAGE[index].STATUS_FLAG == 64)) {
					redirstatus_todisplay = "<label class='classicLabel'>" +
						eLang.getString("common", "STR_RMEDIA_STATUS_START") +
						"</label>";
				}
			}
			image_count++;
			i++;
		}
		try {
			rowJSON.push({cells:[
				{text:(index+1), value:(index+1)},
				{text:imagetype_todisplay, value:imagetype_todisplay},
				{text:imagename_todisplay, value:imagename_todisplay},
				{text:redirstatus_todisplay, value:redirstatus_todisplay}
			]});
		} catch(e) {
			alert(e);
		}
	}

	tblJSON.rows = rowJSON;
	tblImage.loadFromJson(tblJSON);
	lblHeader.innerHTML = "<strong class='st'>" + 
		eLang.getString("common", "STR_MEDIA_IMG_CNT") + "</strong>" + 
		image_count + eLang.getString("common", "STR_BLANK");
}

/*
 * It will invoke the RPC method to start the remote media redirection.
 * Once it get response from RPC, on receive method will be called automatically.
 */
function doStartRedirection(bitStart)
{
	var req;			//xmit object to send RPC request with parameters
	btnStart.disabled = true;
	req = new xmit.getset({url:"/rpc/startredirection.asp", 
		onrcv:startRedirectionRes, status:""});
	req.add("IMAGE_TYPE", 
		tblImage.getRow(tblImage.selected[0]).cells[1].innerHTML);
	req.add("START_BIT", bitStart);
	req.send();
	delete req;
}

/*
 * This is the response function for startRedirection RPC. 
 * Need to check HAPI_STATUS, intimate end user if it returns non-zero value.
 * If zero, then remote media  image redirection is success, intimate proper 
 * message to end user.
 * @param arg object, RPC response data from xmit library.
 */
function startRedirectionRes(arg)
{
	var errstr;		//Error string
	var alertstr = "";
	if (arg.HAPI_STATUS != 0) {
		errstr = eLang.getString("common", "STR_RMEDIA_START_ERR");
		errstr += (eLang.getString("common", "STR_IPMI_ERROR") + 
			GET_ERROR_CODE(arg.HAPI_STATUS));
		alert(errstr);
	} else {
		if (btnStart.value == eLang.getString("common",
			"STR_RMEDIA_START_REDIR")) {
			alertstr = "STR_RMEDIA_REDIR_START";
		} else if (btnStart.value == eLang.getString("common",
			"STR_RMEDIA_STOP_REDIR")) {
			alertstr = "STR_RMEDIA_REDIR_STOP";
		}
		getRMediaCfg();
		alert (eLang.getString("common", alertstr));
	}
}

/*
 * It will design the form, which contains UI controls to add or replace image
 * for remote media configuration, based on the argument value.
 * @param arg object, contains basic details of the selected slot in list 
 * grid and also details to load the form for add or replace image.
 */
function frmRMediaProcessImage(arg)
{
	var frm = new form(arg.frmName, "POST", "javascript://", "general");

	txtImageType = frm.addTextField(eLang.getString("common", 
		"STR_MEDIA_IMGTYPE"), "_txtImageType", 
		arg.imgType, {"readOnly":true}, "classicTxtBox");

	txtImageName = frm.addTextField(eLang.getString("common", 
		"STR_MEDIA_IMGNAME"), "_txtImageName", 
		arg.imgName, {"maxLength":32}, "classicTxtBox");

	var btnAry = [];
	btnAry.push(createButton(arg.btnName, eLang.getString("common", 
		arg.btnValue), function (){
			validateMediaImage(txtImageType.value, txtImageName.value, setMediaImage);
			}));
	btnAry.push(createButton("btnCancel", eLang.getString("common", 
		"STR_CANCEL"), closeForm));

	wnd = MessageBox(eLang.getString("common", arg.wndTitle), frm.display(),
		btnAry);

	//Ignores backspace functionality
	txtImageType.onkeydown = checkBackspace;
	wnd.onclose = getRMediaCfg;
}

/*
 * It will display a form, which contains UI controls to add a new image to
 * remote media.
 * @param index number, index of the selected slot in list grid.
 */
function frmRMediaAddImage(index)
{
	frmRMediaProcessImage({"frmName":"addRMediaImageForm",
		"imgName":"",
		"imgType":RMEDIA_IMAGE[index-1].IMG_TYPE,
		"btnValue":"STR_ADD",
		"btnName":"btnAddImage",
		"wndTitle":"STR_MEDIA_ADD_IMAGE"});
}

/*
 * It will display a form, which contains UI controls to replace a image to
 * remote media.
 * @param index number, index of the selected slot in list grid.
 */
function frmRMediaReplaceImage(index)
{
	frmRMediaProcessImage({"frmName":"replaceRMediaImageForm",
		"imgName":RMEDIA_IMAGE[index-1].IMG_NAME,
		"imgType":RMEDIA_IMAGE[index-1].IMG_TYPE,
		"btnValue":"STR_REPLACE",
		"btnName":"btnReplaceImage",
		"wndTitle":"STR_MEDIA_REPLACE_IMAGE"});
}
