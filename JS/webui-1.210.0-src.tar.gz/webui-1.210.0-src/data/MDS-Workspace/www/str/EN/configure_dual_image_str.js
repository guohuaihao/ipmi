//;*****************************************************************;
//;*****************************************************************;
//;**                                                             **;
//;**     (C) COPYRIGHT American Megatrends Inc. 2008-2012        **;
//;**                     ALL RIGHTS RESERVED                     **;
//;**                                                             **;
//;**  This computer software, including display screens and      **;
//;**  all related materials, are confidential and the            **;
//;**  exclusive property of American Megatrends, Inc.  They      **;
//;**  are available for limited use, but only pursuant to        **;
//;**  a written license agreement distributed with this          **;
//;**  computer software.  This computer software, including      **;
//;**  display screens and all related materials, shall not be    **;
//;**  copied, reproduced, published or distributed, in whole     **;
//;**  or in part, in any medium, by any means, for any           **;
//;**  purpose without the express written consent of American    **;
//;**  Megatrends, Inc.                                           **;
//;**                                                             **;
//;**                                                             **;
//;**                American Megatrends, Inc.                    **;
//;**           5555 Oakbook Parkway, Building 200                **;
//;**     Norcross,  Georgia - 30071, USA. Phone-(770)-246-8600.  **;
//;**                                                             **;
//;*****************************************************************;
//;*****************************************************************;

// File Name  : configure_dual_image
// Brief      : configure_dual_image page string table
// Author Name:
//------------------------------------------------------------//
// configure_dual_image page string table
//------------------------------------------------------------//

eLang.configure_dual_image_strings = {};

eLang.configure_dual_image_strings["CFG_DUAL_IMG_FW_VER"] = "Firmware Version";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_MOST"] = "Most recently updated firmware";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_SAVE"] = "Save";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_LEAST"] = "Least recently updated firmware";
eLang.configure_dual_image_strings["CFG_DUAL_IMG2"] = "Image 2";
eLang.configure_dual_image_strings["CFG_DUAL_IMG1"] = "Image 1";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_BOOT"] = "Image to be booted from upon reset";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_INACTIVE"] = "Select Inactive Image to be booted from upon Reset";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_RESET"] = "Reset";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_TITLE"] = "Dual Image Configuration";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_LOW"] = "Lower firmware version";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_HIGH"] = "Higher firmware version";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_STATE"] = "State";
eLang.configure_dual_image_strings["CFG_DUAL_IMG_DESC"] = "The following option will allow to configure firmware dual image information.";
