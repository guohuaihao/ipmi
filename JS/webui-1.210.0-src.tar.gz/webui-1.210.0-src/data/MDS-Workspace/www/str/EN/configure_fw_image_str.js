//;*****************************************************************;
//;*****************************************************************;
//;**                                                             **;
//;**     (C) COPYRIGHT American Megatrends Inc. 2008-2011        **;
//;**                     ALL RIGHTS RESERVED                     **;
//;**                                                             **;
//;**  This computer software, including display screens and      **;
//;**  all related materials, are confidential and the            **;
//;**  exclusive property of American Megatrends, Inc.  They      **;
//;**  are available for limited use, but only pursuant to        **;
//;**  a written license agreement distributed with this          **;
//;**  computer software.  This computer software, including      **;
//;**  display screens and all related materials, shall not be    **;
//;**  copied, reproduced, published or distributed, in whole     **;
//;**  or in part, in any medium, by any means, for any           **;
//;**  purpose without the express written consent of American    **;
//;**  Megatrends, Inc.                                           **;
//;**                                                             **;
//;**                                                             **;
//;**                American Megatrends, Inc.                    **;
//;**           5555 Oakbook Parkway, Building 200                **;
//;**     Norcross,  Georgia - 30071, USA. Phone-(770)-246-8600.  **;
//;**                                                             **;
//;*****************************************************************;
//;*****************************************************************;

// File Name  : configure_fw_image
// Brief      : configure_fw_image page string table
// Author Name:
//------------------------------------------------------------//
// configure_fw_image page string table
//------------------------------------------------------------//

eLang.configure_fw_image_strings = {};

eLang.configure_fw_image_strings["CFG_FWIMG_DESC"] = "The following option will allow to configure firmware image protocol information.";
eLang.configure_fw_image_strings["CFG_FWIMG_RETRY_CNT"] = "Retry Count";
eLang.configure_fw_image_strings["CFG_FWIMG_TITLE"] = "Image Transfer Protocol";
eLang.configure_fw_image_strings["CFG_FWIMG_SRC_PATH"] = "Source Path";
eLang.configure_fw_image_strings["CFG_FWIMG_PROTOCOL"] = "Protocol Type";
eLang.configure_fw_image_strings["CFG_FWIMG_SAVE"] = "Save";
eLang.configure_fw_image_strings["CFG_FWIMG_RESET"] = "Reset";
eLang.configure_fw_image_strings["CFG_FWIMG_IPADDR"] = "Server Address";
