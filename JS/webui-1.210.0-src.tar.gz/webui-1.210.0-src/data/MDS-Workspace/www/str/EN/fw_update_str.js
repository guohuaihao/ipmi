//;*****************************************************************;
//;*****************************************************************;
//;**                                                             **;
//;**     (C) COPYRIGHT American Megatrends Inc. 2008-2012        **;
//;**                     ALL RIGHTS RESERVED                     **;
//;**                                                             **;
//;**  This computer software, including display screens and      **;
//;**  all related materials, are confidential and the            **;
//;**  exclusive property of American Megatrends, Inc.  They      **;
//;**  are available for limited use, but only pursuant to        **;
//;**  a written license agreement distributed with this          **;
//;**  computer software.  This computer software, including      **;
//;**  display screens and all related materials, shall not be    **;
//;**  copied, reproduced, published or distributed, in whole     **;
//;**  or in part, in any medium, by any means, for any           **;
//;**  purpose without the express written consent of American    **;
//;**  Megatrends, Inc.                                           **;
//;**                                                             **;
//;**                                                             **;
//;**                American Megatrends, Inc.                    **;
//;**           5555 Oakbook Parkway, Building 200                **;
//;**     Norcross,  Georgia - 30071, USA. Phone-(770)-246-8600.  **;
//;**                                                             **;
//;*****************************************************************;
//;*****************************************************************;

// File Name  : fw_update
// Brief      : fw_update page string table
// Author Name:
//------------------------------------------------------------//
// fw_update page string table
//------------------------------------------------------------//

eLang.fw_update_strings = {};

eLang.fw_update_strings["FW_UPDATE_DUAL_FLASH"] = "Image to be updated";
eLang.fw_update_strings["FW_UPDATE_UPDATE"] = "Enter Update Mode";
eLang.fw_update_strings["FW_UPDATE_DUAL_REBOOT"] = "Reboot the device after update";
eLang.fw_update_strings["FW_UPDATE_RESET"] = "Resetting Device.";
eLang.fw_update_strings["FW_UPDATE_TITLE"] = "Firmware Update";
eLang.fw_update_strings["FW_UPDATE_PRSRV_ALL_DESC"] = "This will preserve all the configuration settings during the firmware update";
eLang.fw_update_strings["FW_UPDATE_WARNING"] = "WARNING:";
eLang.fw_update_strings["FW_UPDATE_PRSRV_ALL"] = "Preserve all Configuration.";
eLang.fw_update_strings["FW_UPDATE_PRSRV_CFG"] = "Enter Preserve Configuration";
eLang.fw_update_strings["FW_UPDATE_PROTOCOL"] = "Protocol Type";
eLang.fw_update_strings["FW_UPDATE_PRSRV_CFG_DESC"] = "All configuration items below will be preserved by default during a restore factory default operation. Click &quot;Enter Preserve Configuration&quot; to modify the Preserve status settings.";
eLang.fw_update_strings["FW_UPDATE_DESC3"] = "Preparing device for firmware upgrade.";
eLang.fw_update_strings["FW_UPDATE_DESC2"] = "Closing all active client requests.";
eLang.fw_update_strings["FW_UPDATE_DESC1"] = "Please note that after entering update mode widgets, other web pages and services will not work. All open widgets will be closed automatically. If upgrade process is cancelled in the middle of the wizard, the device will reset.";
eLang.fw_update_strings["FW_UPDATE_UPLOAD"] = "Uploading firmware image.";
eLang.fw_update_strings["FW_UPDATE_DUAL_DSEC"] = "The dual image formation to be used for firmware update is displayed as follows. To configure Image to be booted from upon Reset, choose 'Dual Image Configuration' under Firmware Update menu.";
eLang.fw_update_strings["FW_UPDATE_VERIFY"] = "Verifying firmware image.";
eLang.fw_update_strings["FW_UPDATE_DUAL_ACTIVE"] = "Current Active Image";
eLang.fw_update_strings["FW_UPDATE_FLASH"] = "Flashing firmware image.";
eLang.fw_update_strings["FW_UPDATE_SIGNIMG_KEY"] = "Upload SignImage Key";
eLang.fw_update_strings["FW_UPDATE_DESC"] = "Upgrade firmware of the device. Press &quot;Enter Update Mode&quot; to put the device in update mode.";
eLang.fw_update_strings["FW_UPDATE_PROTO_DESC"] = "The protocol information to be used for firmware image transfer during this update is as follows. To configure, choose 'Image Transfer Protocol' under Configuration menu.";
